# Expressio — Data Room (Vercel)

Este pacote contém:
- `index.html` (site completo com senha + NDA + gráficos + compartilhamento com expiração)
- `vercel.json` (cabeçalhos de segurança e `noindex`)

## Senha
Senha padrão: **Expressio_Headline_2025!**  
(O hash SHA-256 já está aplicado em `index.html`.)

## Como publicar
1. Acesse **vercel.com** → Add New → **Project** → *Deploy a Static Site* (sem repositório).
2. Clique **Upload** e arraste esta pasta com os dois arquivos.
3. Clique **Deploy**. O site sairá como `https://<seu-projeto>.vercel.app`.
4. Abra o site, aceite o NDA e use a senha acima.
5. Use o botão **Share** para gerar links com expiração (48h) e tracking opcional.

## Tracking opcional
- Plausible já está incluído (troque `data-domain` no `<head>`).
- Para logar visualizações em uma planilha, crie um **Apps Script** e cole a URL em `CONFIG.TRACK_URL`.

## Personalização rápida
- Edite o objeto `DATA` no final do `index.html` (receita, envios, LTV/CAC, rotas, cohorts etc.).
- Troque os links em **Documentos** pelos seus PDFs/Sheets.
- Ajuste as cores no `:root` se desejar.
